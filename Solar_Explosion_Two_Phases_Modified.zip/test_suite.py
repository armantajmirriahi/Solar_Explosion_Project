import unittest
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint, solve_ivp
from scipy.stats import f_oneway, norm
import pandas as pd

# Constants
G = 6.67430e-11  # Gravitational constant (m^3/kg/s^2)
M_sun = 1.989e30  # Mass of the Sun (kg)
AU = 1.496e11  # Astronomical unit (m)

def orbit_derivs(y, t, G, M_sun):
    x, y, z, vx, vy, vz = y
    r = np.sqrt(x**2 + y**2 + z**2)
    return [vx, vy, vz, -G*M_sun*x/r**3, -G*M_sun*y/r**3, -G*M_sun*z/r**3]

class TestOrbitalSimulation(unittest.TestCase):
    
    def test_orbital_dynamics(self):
        """Test the orbital dynamics ODE solver"""
        t = np.linspace(0, 3.154e7, 1000)
        y0 = [AU, 0, 0, 0, 29780, 0]
        solution = odeint(orbit_derivs, y0, t, args=(G, M_sun))
        self.assertEqual(solution.shape, (1000, 6))
        self.assertTrue(np.all(np.isfinite(solution)))
    
    def test_monte_carlo_simulation(self):
        """Test Monte Carlo simulation for isotopic ratios"""
        num_simulations = 100000  
        D_H_monte_carlo = np.random.normal(2.5e-4, 5e-6, num_simulations)
        O18_O16_monte_carlo = np.random.normal(0.0022, 8e-6, num_simulations)
        f_stat, p_value = f_oneway(D_H_monte_carlo, O18_O16_monte_carlo)
        self.assertTrue(0 <= p_value <= 1)
    
    def test_orbital_sensitivity(self):
        """Test velocity sensitivity in orbital simulations"""
        t = np.linspace(0, 3.154e7, 1000)
        y0_variations = [[AU, 0, 0, 0, v, 0] for v in [29500, 29780, 30000]]
        for y0 in y0_variations:
            solution = odeint(orbit_derivs, y0, t, args=(G, M_sun))
            self.assertEqual(solution.shape, (1000, 6))
    
    def test_data_integration(self):
        """Test integration of simulated and real-world data"""
        data_simulated = pd.DataFrame({"Time": [1, 2, 3, 4, 5],
        "D/H Variation": [0.0025, 0.0026, 0.0024, 0.0027, 0.0025],
        "O18/O16 Variation": [0.0022, 0.0023, 0.0021, 0.0024, 0.0022]})
        df_apollo = pd.DataFrame({"Time": [1, 2, 3, 4, 5],
        "Apollo Data": [0.0025, 0.0026, 0.0023, 0.0027, 0.0025]})
        df_comparison = data_simulated.merge(df_apollo, on="Time")
        self.assertEqual(df_comparison.shape, (5, 4))
        self.assertTrue(not df_comparison.isnull().values.any())
    
    def test_orbital_visualization(self):
        """Test the visualization of the simulated orbit"""
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.plot([1, 2, 3], [4, 5, 6], [7, 8, 9], label='3D Orbit')
        ax.legend()
        plt.close(fig)
        self.assertTrue(fig is not None)

if __name__ == "__main__":
    unittest.main()
