# Orbital Simulation and Testing Suite

## Introduction
This repository contains the Python scripts for the orbital simulation and isotopic analysis, along with a structured test suite following **Nature Astronomy guidelines**.

## Requirements
The following dependencies must be installed before running the tests:

```bash
pip install numpy scipy pandas matplotlib
```

## Running the Simulation
To execute the main simulation, run:

```bash
python main_script.py
```

## Running the Tests
All test cases can be executed using:

```bash
python -m unittest discover -s tests
```

### Individual Tests:
- **Test Orbital Dynamics** (Numerical integration verification):
  ```bash
  python -m unittest test_suite.TestOrbitalSimulation.test_orbital_dynamics
  ```
- **Test Monte Carlo Simulation** (Statistical validation):
  ```bash
  python -m unittest test_suite.TestOrbitalSimulation.test_monte_carlo_simulation
  ```
- **Test Velocity Sensitivity** (Orbit sensitivity to speed changes):
  ```bash
  python -m unittest test_suite.TestOrbitalSimulation.test_orbital_sensitivity
  ```
- **Test Data Integration** (Data validation against real datasets):
  ```bash
  python -m unittest test_suite.TestOrbitalSimulation.test_data_integration
  ```
- **Test Orbital Visualization** (Graph generation verification):
  ```bash
  python -m unittest test_suite.TestOrbitalSimulation.test_orbital_visualization
  ```

## Output Verification
After running the tests, the expected successful output should include:

- **Total Tests Run:** 5  
- **Errors:** 0  
- **Failures:** 0  
- **Success:** True  

If any errors occur, ensure dependencies are correctly installed and rerun the tests.

## Data Reproducibility
The datasets used in the tests simulate real data from the Apollo, Genesis, and Mars Rover missions. These tests validate data processing integrity and ensure that results match expected physical behavior.

## License
This code is distributed under the **MIT License**. Feel free to modify and share within compliance of the license.

## Further Information
For more details, refer to the [GitHub Repository](https://github.com/your-repo) or the corresponding paper.
